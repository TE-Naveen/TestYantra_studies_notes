let arr = ["kiran", "m", "G", 10000, {}];
let [fn, mn, , ln, other = "ntg"] = arr;
console.log(fn);
console.log(ln);
console.log(other);

console.log(arr);
let arr2 = [1, 2, 3, 4, 5, 6, 7, 8, 8, 9, 0, 11, 23, 66];
let [a, b, c, ...d] = arr2;

console.log(a, b, c);
console.log(d);

var human = {
  name: "Harikrishnan",
  gender: "Male",
  weight: 100,
  height: 6,
  hobbies: ["watching serial", "music", "dancing"],
  role:"Developer"
};
 
let {name:user , weight , height ,role:desig="Dev" , hobbies } = human;
console.log(user);
console.log(weight);
console.log(hobbies);
console.log(desig);

console.log("------------");

let {name:user1 , ...otherInfo } = human;
console.log(user1);
console.log(otherInfo);