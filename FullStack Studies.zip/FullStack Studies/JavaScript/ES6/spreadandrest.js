let arr1 = [1,2,3,4,5,6,7,8,9];
let arr2 = [10,11,12,13, ...arr1]
console.log(arr2);

let data = {
    name:"kiran",
    age:19
}
console.log(data);

let duplicateDate = {
    ...data,
    salary:0
}
console.log(duplicateDate);

//rest operator
function add(...numbers) {
    // console.log(numbers);
    let sum = 0;
    for (let i of numbers) {
        sum = sum + i
    }
    console.log(sum);
}

add();
add(1,2,3,4,5);
add(10,187,124,8687);