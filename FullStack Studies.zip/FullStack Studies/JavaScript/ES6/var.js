let brand ;
brand= "Apple";
console.log(" Global Scope : ", brand); //Apple

function prrintData() {
    let brand = "Nike"
    console.log("Function Scope : " , brand  ); // Nike
}
prrintData();

if(true){
    let brand = "PUMA";
    console.log("Block Scope : ", brand); //Puma
       
}

console.log(" Global Scope : ", brand); // apple


const tech = "HTML";
console.log(" Global Scope : ", tech); //HTML

function prrintData() {
    const tech = "CSS"
    console.log("Function Scope : " , tech  ); // CSS
}
prrintData();

if(true){
    const tech = "JS";
    console.log("Block Scope : ", tech); //JS
       
}

console.log(" Global Scope : ", tech); // HTML

function add(a=0,b=0) {
    console.log("inside add");
    console.log(a+b);
}


add();



