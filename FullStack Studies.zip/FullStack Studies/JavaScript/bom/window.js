function getUserData() {
   var name = prompt("Enter User Name");
   if (name != null && name.length > 0) {
       alert(`Welcome ${name}`)
       var age = prompt("Enter Age");
       if (age < 18) {
           alert("You are not allowed");
           close() 
       } else {
           open('https://google.com');
       }
   }else{
       alert("Name can not be empty")
       document.getElementById("btn").click();
   }
}