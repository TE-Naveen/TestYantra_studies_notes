// // var numbers = [11,22,333,44,55,66,77,88,333,55,88,22];

// // //includes(searchElement, [fromIndex] )
// // console.log(numbers.includes(11,4));

// // //push(element/elements)
// // console.log(numbers , numbers.length , "org");
// // var newLength = numbers.push(100)
// // // var newLength = numbers.push(10000, 12,32,454) 
// // console.log(numbers , newLength,  " after push");

// // //pop()
// // console.log(numbers , "before pop");
// // console.log(numbers.pop());
// // console.log(numbers , "after pop");

// // console.log(" ------- unshift --------------");
// // //unshift(element/elements)
// // console.log(numbers , "before unshift" , numbers.length);
// // // var nwLength = numbers.unshift(150);
// // var nwLength = numbers.unshift(150 ,160,180);
// // console.log(numbers , "after unshift" , nwLength);

// // console.log(" ------- shift -------");
// // console.log(numbers , "before shift");
// // console.log(numbers.shift());
// // console.log(numbers , "after shift");

// // console.log("---- indexOf ------");
// // //indexOf(searchElement, [fromIndex])
// // console.log(numbers);
// // console.log(numbers.indexOf(11));// 2
// // console.log(numbers.indexOf(11,3)); //-1

// // console.log(" -------- splice -----------");
// // console.log(numbers);
// // var res = numbers.splice(3,4,777,888,999,1111,3333,4555)
// // console.log(res);
// // console.log("org" , numbers);

// // console.log(" ---- slice -------");
// // console.log(numbers);
// // var op = numbers.slice(5,10)
// // console.log(op);
// // console.log("after slice" , numbers);

// var arr = [1,2,3,4,6,7,8];
// console.log("org " , arr);
// var modified = arr.map(
//     (data)=>{
//         // console.log(data , i );
//         return data*2;
//     }
//   )
//   console.log(modified);
//   console.log(" after map " ,arr);

// console.log("---- filter --------");
// var arr1 = [1,2,3,4,5,6,7,8];
// console.log(arr1 , "before");  
// var filtered  = arr1.filter(
//     data=>data%2!=0
// )
// console.log(filtered);
// console.log(arr1 , "after");

// var arr2 = [1,3,,45,5,,7,8,9]
// arr2["nn"] = "Kiran"
// arr2.forEach((data, index)=>{
//     console.log(data , index);
// })


