function outerFuntion(a) {
    var b = 10;
    console.log("Outer function ", a , b);
    function innerFunctoion() {
        console.log("Inner function ", a , b);
    }
   return  innerFunctoion;
}

// var output = outerFuntion(200);
// output();

function getData(ref) {
    // console.log(ref);
   console.log( ref(10));

}
function display() {
    console.log("Call back Function " );
    return 1000000;
}

getData(display);

getData((a)=>{
    console.log("This is Arrow Function as callback",a);
    // return 2000;
})

getData(function(b){
    console.log("This is  Function Expression as callback ", b);
})