var human = {
    name:"Harikrishnan",
    gender:"Male",
    weight:100,
    height:6.0,
    hobbies:["watching serial","music" ,"dancing" ],
    isMarried:true,
    hasChildren:undefined,
    dob:new Date(),
    address:{
        houseNo:"#420",
        city:"Thanjavur"
    },
    working:function(){
        console.log(this.name , " is working");
    },
    sleeping:()=>{
        console.log(human.name , " sleeps for 24hrs");
    }

}

console.log(human);

var data = new Object();
data.fname = "p"
data.address = {};
data.address.city = "Chennai"
console.log(data);
