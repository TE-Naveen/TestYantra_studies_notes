//create a element and append to body
var ptag = document.createElement("p");
ptag.innerHTML = "<h1>Welcome to JS Class</h1>";
// ptag.innerText = "<h1>Welcome to JS Session</h1>";
// ptag.textContent = "welcome To Chennai"
document.body.appendChild(ptag);
console.log(ptag);

var titleTag = document.createElement("title");
titleTag.innerText = "JS | DOM";
document.head.appendChild(titleTag);

var link = document.createElement("a");
link.innerText = "LinkedIn";
link.href = "https://linkedin.com";
link.style.color = "red";
link.style.textDecoration = "none";
link.style.fontSize = "25px";
link.style.margin = "300px";
link.style.border = "2px solid blue";
link.style.padding = "10px";
link.id = "test";
link.name = "test";

document.body.appendChild(link);

console.log(link);

var topicTag = document.getElementById("topic");
topicTag.innerText = "JavaScript";
console.log(topicTag);

var btn = document.getElementById("btn");
btn.addEventListener("click", createNewEle);
btn.addEventListener("mouseover", enLarge);
btn.addEventListener("mouseout", () => {
  btn.style.fontSize = "20px";
});

var ptag = document.createElement("p");
ptag.innerHTML = "<h1>This is coming from Event</h1>";

function createNewEle() {
  document.body.appendChild(ptag);
  console.log(ptag);
  //   btn.hidden = true
  btn.removeEventListener("click", createNewEle);//
}
 
function enLarge() {
  btn.style.fontSize = "40px";
}


var content = document.getElementById("content");
var oldText = content.innerText;

content.addEventListener("mouseover" , ()=>{
    content.innerText= " Java Developers..........";
})

content.addEventListener("mouseout" , ()=>{
    content.innerText= oldText;
})
