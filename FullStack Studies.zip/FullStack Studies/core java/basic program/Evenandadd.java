package com.ty.mock.prepare;

public class Evenandadd {

static	public void method(int number) {
 for (int i = 1; i <= number; i++) {
	String a =(i%2==0)?"Even number "+i :"odd number " + i;
	System.out.println(a);
	}
}


public static void main(String[] args) {
 Evenandadd.method(10);

}}