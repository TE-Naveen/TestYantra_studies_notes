package com.ty.mock.prepare;

public class Prime {
	static int flag=1;
  public static void primes(int num) {
	  
	  if(num==1||num==0) {
		  System.out.println("Not a prime");
		  return ;
	  }
		for(int i =1; i<=num/2;i++) {
		if((num/2)%i==0) {
	System.out.println("Not a prime");
	break;
	}else {
		System.out.println("prime");
		break;
	}
		}
  }

	public static void main(String[] args) {

	Prime.primes(5);
	
	
  }
 }