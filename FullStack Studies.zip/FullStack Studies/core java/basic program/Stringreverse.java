package com.ty.mock.prepare;

public class Stringreverse {
	public static void main(String[] args) {
		
		String original = "madam";
		String onew = "";
		
		for(int i=original.length()-1;i>=0;i--) {
			
			onew = onew+original.charAt(i);
			
		}
	
		if(original.equalsIgnoreCase(onew)) {
			System.out.println("palindrome");
		}else {
			System.out.println("not a palindrome");
		}
		
		
	}

}
