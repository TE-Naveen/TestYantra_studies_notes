package com.ty.mock.prepare;

public class fibonaci {
	
static void med(int num) {
		int a=0;
		int b=1;
		int c;
		for (int i = 0; i < num; i++) {
			System.out.println(a+" ");
		c=a+b;
		a=b;
		b=c;

		}
		
		
		
	}
	
	
	public static void main(String[] args) {
	fibonaci.med(10);
}
	}
