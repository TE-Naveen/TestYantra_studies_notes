package com.te.collectionimpl.setimpl;

import java.util.TreeSet;

import com.te.collectionimpl.beans.Employee;

public class TreeSetEmployeeDetails {

	public static void main(String[] args) {
		Employee employee1 = new Employee(90, "Praveen", "Developer", 90000.9, "Bosh");
		Employee employee2 = new Employee(70, "Hulk", "Destructor", 100000.9, "Marvel");
		Employee employee3 = new Employee(80, "Thor", "Thunder", 20900.9, "Asgard");
		Employee employee4 = new Employee(20, "Lucy", "Monster", 70090.9, "Anywhere");
		Employee employee5 = new Employee(10, "SuperMan", "Reporter", 90000.8, "DC");

		TreeSet<Employee> employees = new TreeSet<Employee>();
		employees.add(employee1);
		employees.add(employee2);
		employees.add(employee3);
		employees.add(employee4);
		employees.add(employee5);
//
		/*
		 * Iterator<Employee> iterator = employees.iterator();
		 * 
		 * while (iterator.hasNext()) { Employee employee = (Employee) iterator.next();
		 * System.out.println(employee); }
		 */
		
		for (Employee employee : employees) {
			System.out.print(employee);
			System.out.println();
		}
		
	}
}
