package com.ex.exception.custom.unchecked;

public class InvalidCredentialsException extends RuntimeException {
	 /**
	 * 
	 */
	private static final long serialVersionUID = -705932668388531394L;

	public InvalidCredentialsException(String msg) {
		
		super(msg);
	 }
}
	
		
	


