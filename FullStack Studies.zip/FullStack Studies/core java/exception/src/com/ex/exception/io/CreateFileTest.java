package com.ex.exception.io;

public class CreateFileTest {
	public static void main(String[] args) {
		
		CreateFile ref =new CreateFile();
		  ref.createFile("C:\\Users\\david\\Desktop\\siva\\java.text");
	}

}
