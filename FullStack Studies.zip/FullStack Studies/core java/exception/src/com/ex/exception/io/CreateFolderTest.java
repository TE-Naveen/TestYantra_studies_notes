package com.ex.exception.io;

public class CreateFolderTest {
	public static void main(String[] args) {
		CreateFolder ref= new CreateFolder();
	      ref.createFloder("C:\\Users\\david\\Desktop\siva\naveen");
	
	}
}


