package com.ex.exception.te;

public class ClassLoader {
	public static void main(String[] args) {
		try {

Emplooye employee=(Emplooye) class.forName("com.ex.exception.te.Emplooye").newInstance();
			System.out.println(employee);  
System.out.println("loaded sucessfully");
		} catch (Exception e){
			e.printStackTrace();
		}
	}

}
