package com.ex.exception.te;


public class Cloneobject implements Cloneable{
	public static void main(String[] args) {
		
		Emplooye employee= new Emplooye();
		employee.setEname("dinesh");
		employee.setRole("developer");
		employee.setSalary(20000);
		employee.setEid(10);
		System.out.println("beore change");
		
		Emplooye employee2 =null;
			try {
				System.out.println("emp"+ employee);
				employee2=(Emplooye) employee.clone();
				System.out.println("employee2"+ employee2);
			} catch (CloneNotSupportedException e) {
				// TODO Auto-generated catch block
                 System.out.println("clone supported");
			}
		
			
		System.out.println("after changes");
		employee.setEid(3);
		employee.setEname("siva");
		System.out.println(employee);
		System.out.println(employee2);
			
	}

}
