package com.ex.exception.te;

public class Emplooye {
	private int eid;
	private String ename;
	private double salary;
	private String role;
	
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return this.eid;
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
        return this.hashCode()==obj.hashCode();
	}
	@Override
	public String toString() {
		return "Emplooye [eid=" + eid + ", ename=" + ename + ", salary=" + salary + ", role=" + role + "]";
	}
	
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	

}
