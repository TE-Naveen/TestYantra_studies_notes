package com.ex.exception.te;

import java.util.Scanner;

public class LoginTest {
public static void main(String[] args) {
	
	Scanner scanner= new Scanner(System.in);
	System.out.println("enter the user name");
	String user =scanner.next();
	
	System.out.println("enter the psw");
	String pwd =scanner.next();
	
	LoginToAdmin admin = new LoginToAdmin();
	try {
		admin.login(user, pwd);
	} catch (IllegalAccessException e) {
		System.out.println(e.getMessage());
		System.out.println("ill");
	}
	scanner.close();
}
}
