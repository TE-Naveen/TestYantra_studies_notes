package com.ex.exception.te;

public class LoginToAdmin {
	public void login(String user ,String pwd) throws IllegalAccessException {
		
		if(user.equalsIgnoreCase("admin")) {
			if(pwd.equalsIgnoreCase("admin123")) {
				System.out.println("login sucess");
			} else {
				throw new IllegalAccessException("wrong password");
			}
			} else{
				throw new IllegalAccessException("wrong credentials");
			}
		
	}
	}


