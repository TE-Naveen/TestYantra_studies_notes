package com.ex.exception.te;

public class MyException {
	public static void main(String[] args) {
       try{
    	   try {
			int a=10;
      int b=0;
      int c =a/b;
		} catch (ArithmeticException e) {
			// TODO Auto-generated catch block
			System.out.println("divide by zero is not possible");
		}
      String ref= null;
      ref.length();
       }catch (NullPointerException e) {
    	   System.out.println("String is null");
       }
	

}
	}
