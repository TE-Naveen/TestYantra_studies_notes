package com.ex.exception.te;

import java.io.File;
import java.util.Scanner;

public class Practice {

	void getData(int a, int b, String filename) {
		System.out.println(divide(a,b));
		fileReader(filename);
	}
	public int divide(int a, int b) {
		if(a>0 && b>0) {
			return a/b;
		}else {
			return 0;
		}
	}
	public void fileReader(String filename) {
		try {
			Scanner scanner =new Scanner(new File(filename));
			  
			while(scanner.hasNext()) {
				System.out.println(scanner.hasNextLine());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
