package com.ex.exception.te;

public class TestPractice {
public static void main(String[] args) {
    Practice practice = new Practice();
    String filename="C:\\Users\\david\\Desktop\\file.txt";
    practice.getData(10, 2, filename);
}
}
