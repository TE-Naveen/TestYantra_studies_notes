package com.te.exceptions;

import com.te.exceptions.exp.InvalidCredentialsException;

public class ATMUtil {

	public static ATMSimulator pinCheck(int pin) {
		if (pin == 1880) {
			return new ATMSimulator();
		}else{
			throw new InvalidCredentialsException("Wrong Pin , try again Later..!!");
		}
	}
}
