package com.te.exceptions;

public class TryBlockTest {
	
	public static void main(String[] args) {
		// 
		try {
			int  c = 10/0;
			System.out.println("Try block");
		} 
		
		finally {
			System.out.println("Finally block");
		}
		
	}
}
