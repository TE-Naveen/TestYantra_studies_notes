package com.te.exceptions.exp;

public class InSufficientBalance extends Exception {

	public InSufficientBalance(String msg) {
		super(msg);
	}
}
