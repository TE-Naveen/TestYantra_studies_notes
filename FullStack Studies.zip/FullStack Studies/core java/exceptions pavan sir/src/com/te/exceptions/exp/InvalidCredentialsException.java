package com.te.exceptions.exp;

public class InvalidCredentialsException extends RuntimeException{

	public InvalidCredentialsException(String msg) {
		super(msg);
	}
}
