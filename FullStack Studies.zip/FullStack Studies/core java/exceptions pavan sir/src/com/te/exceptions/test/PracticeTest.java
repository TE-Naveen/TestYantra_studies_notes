package com.te.exceptions.test;

public class PracticeTest {

	public static void main(String[] args) {
		Practice practice = new Practice();
		String fileName = "C:\\Users\\Pavan Kumar\\Desktop\\java.txt";
		practice.getData(10, 0, fileName);
	}
}
