package com.te.java8eatures;

import java.io.ObjectInputStream.GetField;
import java.time.LocalDate;

public class DateTimeTest {
public static void main(String[] args) {
	
	LocalDate date =  LocalDate.now(); //
	
	LocalDate date2 = LocalDate.parse("1997-09-09");
	System.out.println(date);
	
	System.out.println("day of month "+ date.getDayOfMonth());
	
	System.out.println("date of year "+ date.getDayOfYear());
	System.out.println("month "+ date.get(field));
	
	
}
	
}
