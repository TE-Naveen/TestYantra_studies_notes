package com.te.java8eatures;

import java.util.ArrayList;
import java.util.List;

public class ForEachMethod {

	public static void main(String[] args) {
		
		List<Integer> integer = new ArrayList<Integer>();
		integer.add(3);
		integer.add(7);
		integer.add(34);
		integer.add(76);
		integer.add(97);
		integer.add(56);
		
		System.out.println("org " + integer);
		integer.forEach(a->System.out.println(a*a));
		System.out.println("after for each " + integer);
		
		System.out.println("--by using method reference--");
		integer.forEach(System.out::println);
		
		System.out.println();
		integer.forEach(ForEachMethod::getData);
		
		
//		integer.removeIf(x->{
//			return x > 7;
//		});
//		
		//integer.removeIf(x->x>7);
		
		integer.removeIf(ForEachMethod::filter);
		System.out.println("after remove If " + integer);
	
		
		
		}
	
	public static void getData(int a) {
		System.out.println(a+ "from other method");
		
	}
	
	public static boolean filter(int a) {
		return a>7;
	}
}
