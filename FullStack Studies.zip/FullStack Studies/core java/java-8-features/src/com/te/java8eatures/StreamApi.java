package com.te.java8eatures;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class StreamApi {
	public static void main(String[] args) {

		List<Integer> integer = new ArrayList<Integer>();
		integer.add(3);
		integer.add(7);
		integer.add(34);
		integer.add(76);
		integer.add(97);
		integer.add(56);
		System.out.println("org " + integer);

		// convert manipulated data to list
		List<Integer> mapoutput = 
				integer.stream().map(x -> x * x).collect(Collectors.toList());

		Set<Integer> mapsetoutput =
				integer.stream().map(x -> x * x).collect(Collectors.toSet());

		System.out.println("map " + mapoutput);
		System.out.println("mapset " + mapsetoutput);
	
		// integers = mapoutput ;reassign the data
		System.out.println("after map operation " + integer);

		System.out.println("------Stream-sorted()---");

		List<Integer> sortedlist = integer.stream().sorted().collect(Collectors.toList());
		System.out.println(sortedlist);
		System.out.println("org" + integer);

		System.out.println("----Even Number---");
		List<Integer> evenNumbers = integer.stream().map((a) -> {
			if (a % 2 == 0) {
				return a;
			} else {
				return a + 1;
			}
		}).collect(Collectors.toList());
		System.out.println(evenNumbers);

		System.out.println("---distinct-------");
		List<Integer> dislist = integer.stream().distinct().collect(Collectors.toList());
		System.out.println("distinct list " + dislist);
		
		System.out.println("--count -");
		
		long count = integer.stream().count();
		System.out.println("count " + count);
		
		System.out.println("p------skip-------------------");
		List<Integer> skip = integer.stream().skip(4).collect(Collectors.toList());
		 System.out.println("after skiped " +skip);    ///skip will skip the first 4 data
		 
		 System.out.println("--------filter-----------");
		 System.out.println("org" + integer);
		 List<Integer> filter = integer.stream().filter(x-> x%2!=0).collect(Collectors.toList());
		   System.out.println("filter list"+ filter);
		   
		
		
		
	}

}
