package com.te.java8eatures;

import javajar.Javautills;

public class UtilTest {
	 
	public static void main(String[] args) {
		Javautills util = new Javautills();
		
		util.first();
		util.second();
	}
}
