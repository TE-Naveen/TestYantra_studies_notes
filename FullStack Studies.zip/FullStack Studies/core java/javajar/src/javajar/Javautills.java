package javajar;

public class Javautills {
	public void first() {
		
	}
	public String second() {
		System.out.println("second method from java utills");
		return "java utill @author david";
	}

}
