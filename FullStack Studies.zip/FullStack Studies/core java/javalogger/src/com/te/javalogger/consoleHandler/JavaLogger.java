package com.te.javalogger.consoleHandler;

import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.XMLFormatter;

public class JavaLogger {
	  final static Logger LOGGER =Logger.getLogger(JavaLogger.class.getName());
	  public static void main(String[] args) {
		
		  ConsoleHandler consoleHandler = new ConsoleHandler();
		//BY DEFAULT SIMPLE FORMAT  
		  consoleHandler.setLevel(Level.CONFIG);
		  
		 // consoleHandler.setFormatter(new XMLFormatter());
		  //WE CAN CHANGE BY XML FORMAT
		  
		  LOGGER.severe("server msg");
		  LOGGER.warning("WARNNG MSG");
		  LOGGER.info("INFO MSG");
		  LOGGER.config("CONFIG MSG");
		  LOGGER.fine("FINE MSG");
		  LOGGER.finer("FINER MSG");
		  LOGGER.finest("FINEST MSG");
		  
	}
	  

}
