package com.te.javalogger.customFormatter;

import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class CustomFormatterTest {

	 final static Logger  LOGGER = Logger.getLogger(CustomFormatter.class.getName());
	
	public static void main(String[] args) {
		
	
 try {
	 FileHandler fileHandler = new FileHandler("myLog.logs",true);
    fileHandler.setLevel(Level.ALL);
	   fileHandler.setFormatter(new CustomFormatter());
				   
           LOGGER.addHandler(fileHandler);
				      LOGGER.severe("server msg");
					  LOGGER.warning("WARNNG MSG");
					  LOGGER.info("INFO MSG");
					  LOGGER.config("CONFIG MSG");
					  LOGGER.fine("FINE MSG");
					  LOGGER.finer("FINER MSG");
					  LOGGER.finest("FINEST MSG");
					  
					}
					catch(Exception e) {
						
					}	
			
}	
		
}
