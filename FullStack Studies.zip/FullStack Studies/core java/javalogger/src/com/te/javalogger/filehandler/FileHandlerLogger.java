package com.te.javalogger.filehandler;

import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class FileHandlerLogger {
 final static 	Logger LOGGER = Logger.getLogger(FileHandler.class.getName());

 public static void main(String[] args) {
 try {
 FileHandler fileHandler = new FileHandler("myLog.logs",true);
    fileHandler.setLevel(Level.ALL);
   fileHandler.setFormatter(new SimpleFormatter());
   
   LOGGER.addHandler(fileHandler);
      LOGGER.severe("server msg");
	  LOGGER.warning("WARNNG MSG");
	  LOGGER.info("INFO MSG");
	  LOGGER.config("CONFIG MSG");
	  LOGGER.fine("FINE MSG");
	  LOGGER.finer("FINER MSG");
	  LOGGER.finest("FINEST MSG");
	  
	}
	catch(Exception e) {
		
	}
 
	
}
}
