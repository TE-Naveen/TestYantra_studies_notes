package com.te.javalogger.filter;

import java.util.logging.Filter;
import java.util.logging.Level;
import java.util.logging.LogRecord;

public class MyFilter implements Filter{

	@Override
	public boolean isLoggable(LogRecord record) {
		// TODO Auto-generated method stub
	if(record.getLevel()==Level.FINE) {
		return false;
	}
	if(record.getLevel()==Level.FINEST) {
		return false;
	}
		
		
		return true;
	}

	
	
}
