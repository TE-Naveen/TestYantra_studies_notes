package com.te.collection.myarrayversion;

public class MyArray1 {
	private int []arr;
	private int position = 0;
	private final int Default_Size=5;

	public MyArray1() {
		arr = new int [Default_Size];
	}
	
	public  MyArray1(int initsize) {
		arr= new int [ initsize];
	}
	
	public boolean add(int element) {
		
		if(position<arr.length) {
			arr[position++] =element;
		}else {
			//claculation new size
			int newSize = arr.length+(arr.length/2);
			int [] arr2 = new int [newSize];
			
			//copying the old array to
			for(int i=0;i<arr.length;i++) {
				 arr2[i]=arr[i];
			}
			arr=arr2;
			arr[position++]= element;
		}
		return true;
	}
	
	public int get(int index) {
		return arr[index];
	}
	public int size() {
		return arr.length;
	}
	
	
}
