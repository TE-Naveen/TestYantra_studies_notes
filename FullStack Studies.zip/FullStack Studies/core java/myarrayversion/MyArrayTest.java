package com.te.collection.myarrayversion;

public class MyArrayTest {
	public static void main(String[] args) {
		
	MyArray1 array= new MyArray1();
	// MyArrayV1 array = new MyArrayV1(4); 
	 System.out.println(array.add(10));
	 System.out.println(array.add(20));
	 System.out.println(array.add(30));
	 System.out.println(array.add(40));
	 System.out.println(array.add(50));
	 System.out.println(array.get(0));
	 System.out.println("-----------------------");
	 System.out.println(array);
	    		
	}
				 
}
