package com.te.collection.myarrayversion;

public class MyArrayV4Test {

	public static void main(String[] args) {
		
		MyArrayV4 array = new MyArrayV4();
		System.out.println(array.size());
		System.out.println(array.add(10));
		System.out.println(array.add("true"));
		System.out.println(array.add("r"));
		System.out.println(array.add(false));

		System.out.println(array.add(null));
		System.out.println(array.size());

		System.out.println("------------after adding extra element-----");

		System.out.println(array.add(60));
		System.out.println(array.size());

		System.out.println("reading data");
		System.out.println(array);

		System.out.println("setting the value");
		array.set(4, 90);
		array.set(0, 99);

		System.out.println(array);

		System.out.println("Removing the element by index");
		System.out.println("before removing---->" + array.size());// 6
		array.remove(0);
		array.remove(5);
		System.out.println("after removing------>" + array.size());// 4
		System.out.println(array);

	}

}
