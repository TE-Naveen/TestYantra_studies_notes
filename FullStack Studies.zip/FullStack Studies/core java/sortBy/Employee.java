package com.te.collection.sort;

public class Employee implements Comparable<Employee>{
	
	private String role;
	private Double salary;
	private String Client;
	private String name;
	private Integer id;
	
	
	public Employee(String role, Double salary, String client, String name, Integer id) {
		super();
		this.role = role;
		this.salary = salary;
		this.Client = client;
		this.name = name;
		this.id = id;
	}
	
		

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public String getClient() {
		return Client;
	}
	public void setClient(String client) {
		Client = client;
	}
	
	@Override
	public String toString() {
		return "\n Employee [id=" + id + ", name=" + name + ", role=" + role + ", salary=" + salary + ", Client=" + Client
				+ "]";
	}
	
	@Override
	public int hashCode() {
		return this.id;
	}

	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		return this.id-o.id;
		
		//return o.id -this.id   ---->
		
	}
	
	
	
	
}
