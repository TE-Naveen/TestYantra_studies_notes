package com.te.collection.sort;

import java.util.Scanner;
import java.util.TreeSet;

public class SortByTest {
	public static void main(String[] args) {

		System.out.println("sort by \n 1.id \n 2.name \n 3.Salary\n 4.client");
		System.out.println("choose your option");
		Scanner scanner = new Scanner(System.in);
		int optn = scanner.nextInt();

		TreeSet<Employee> employee = null;

		switch (optn) {
		case 1:
			employee = new TreeSet<Employee>();
			break;
		case 2:
			employee = new TreeSet<Employee>(new SortByName());
			break;
		case 3:
			employee = new TreeSet<Employee>(new SortBySalary());
			break;
		case 4:
			employee = new TreeSet<Employee>(new SortByClient());
			break;
		default:
			System.out.println("wrong option");
		}
		Employee employee1= new Employee("TESTING",10.0,"INFO","David",2);
		Employee employee2= new Employee("developing",109.0,"testyantra","vaith",3);
		Employee employee3= new Employee("TESTING",109873.0,"techno","",4);
		Employee employee4= new Employee("frontend",134.0,"elevate","ajith",1);
		
 employee.add(employee1);
 employee.add(employee2);
 employee.add(employee3);
 employee.add(employee4);

 System.out.println(employee);
		

	}

}
