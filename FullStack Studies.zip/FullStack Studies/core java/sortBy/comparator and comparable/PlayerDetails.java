package com.hp.practices.sort;

import java.util.Comparator;

public class PlayerDetails implements Comparator<PlayerDetails>{
	private String name;
	private int number;
	private String country_name;
	
	

	public PlayerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	PlayerDetails(String name, int number, String country_name) {
		super();
		this.name = name;
		this.number = number;
		this.country_name = country_name;
	}

	public String getName() {
		return name;
	}

	public int getNumber() {
		return number;
	}

	public String getCountryName() {
		return country_name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setCountry(String countryname) {
		this.country_name = countryname;
	}

	public void setNumber(int number) {
		this.number = number;

	}
	
	public String toString() {
		return " \n [ name = " +name + " number = " + number +" country = "+ country_name
				+ "]";
	}

//	@Override
//	public int compareTo(PlayerDetails o) {
//		// TODO Auto-generated method stub
//		return this.number-o.number;
//	}

	@Override
	public int compare(PlayerDetails o1, PlayerDetails o2) {
		// TODO Auto-generated method stu
		return o1.getName().compareTo(o2.getName());
	}


	
	

}
