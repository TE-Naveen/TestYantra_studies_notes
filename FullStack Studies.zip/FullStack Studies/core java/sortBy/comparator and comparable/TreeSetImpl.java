package com.hp.practices.sort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

public class TreeSetImpl {
	
	
	
	public static void main(String[] args) {
		
		PlayerDetails player1 = new PlayerDetails("NAVEEN",9,"INDIA");
		PlayerDetails player2 = new PlayerDetails("DINESH",02,"JAPAN");
		PlayerDetails player3 = new PlayerDetails("ADEL",8,"SRILANKA");
		
		PlayerDetails ref = new PlayerDetails();
		Comparator<PlayerDetails> ab=(a,b)->{
		return a.getName().compareTo(b.getName());
	};
		List<PlayerDetails> treeset = new ArrayList();
		
		treeset.add(player1);
		treeset.add(player2);
		treeset.add(player3);
		
		Collections.sort(treeset,ab);
		System.out.println(treeset);
		
		Iterator<PlayerDetails> itr = treeset.iterator();
		while (itr.hasNext()) {
			System.out.println( itr.next());
			
		}
		
//		TreeSet treeset1 = new TreeSet();
//	    treeset1.add(2);
//	    treeset1.add(3);
//	    treeset1.add(2);
//	    treeset1.add(82);
//	    treeset1.add(1);
//	    
//	    System.out.println(treeset1);
//	    
		
	}
	

	
}
