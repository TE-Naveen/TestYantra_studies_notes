package com.te.threads.lamda;

public class Interface2Test {

	public static void main(String[] args) {
		
		MyInterface2 ref = (q)->{
			System.out.println(q);
		};
		MyInterface2 ref2 = (c)->{
			System.out.println(c);
		};
		
		ref.count2(10);
 		ref2.count2(3);
	}
}
