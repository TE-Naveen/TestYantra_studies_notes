package com.te.threads.lamda;

public interface MyInterface1 {
	 void count();


}
