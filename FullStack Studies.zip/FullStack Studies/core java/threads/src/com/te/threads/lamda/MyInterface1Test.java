package com.te.threads.lamda;

public class MyInterface1Test {
	public static void main(String[] args) {
		
		MyInterface1 ref = ()->{
			System.out.println("inside the count method");
		};
		MyInterface1 ref2 = ()->{
			System.out.println("2nd impl");
		};
		
		ref.count();
	    ref2.count();
		
	}
}
