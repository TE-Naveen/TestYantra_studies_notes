package com.te.threads.lamda;

public interface MyInterface2 {

	void count2(int a);
	
}
