package com.te.threads.raise;

public class Bank {

	int amount = 10000;
	
	public synchronized void withDraw(int money) {
		System.out.println("----going to withdraw---");
		if( money >amount) {
			
			System.out.println("less balance wating for deposite");
		}
		try {
			wait(); //wait method unlock the object till after getting 
			          // back the response from notify then lock the object
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			
		}
		amount -= money;
		System.out.println("withdraw sucessful");
		
	}
	public synchronized void deposite(int money) {
		System.out.println("depositing money");
		amount += money;
		System.out.println("deposite sucessfull");
		notify();
	}
	
}
