package com.te.threads.runnableimpl;

public class ThreadOne implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("---------ThreadOne Start ----");
        String str [] = {"a","b","c","d"};
        for (String string : str) {
			System.out.println(string);
		}
        System.out.println("----------Threadone Ends----");
		
	}

	
}
