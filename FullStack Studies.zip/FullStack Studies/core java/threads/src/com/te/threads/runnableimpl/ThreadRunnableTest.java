package com.te.threads.runnableimpl;

public class ThreadRunnableTest {

	public static void main(String[] args) {
		System.out.println("--------main starts");
		ThreadOne one = new ThreadOne();
		ThreadTwo two = new ThreadTwo();
		
		Thread ref = new Thread(one);
		Thread ref2 = new Thread(two);
		ref.start();
		ref2.start();
		
		System.out.println("-------main ends -------");
		
	}
}
