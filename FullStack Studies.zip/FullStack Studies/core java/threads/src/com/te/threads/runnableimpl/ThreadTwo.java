package com.te.threads.runnableimpl;

public class ThreadTwo implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("--------ThreadTwo run Start method");
	int [] num= {3,4,2,7,10};
	for (int i : num) {
		System.out.println(i);
	}
	System.out.println("----------Threadtwo end method End----");
		
	}
	

}
