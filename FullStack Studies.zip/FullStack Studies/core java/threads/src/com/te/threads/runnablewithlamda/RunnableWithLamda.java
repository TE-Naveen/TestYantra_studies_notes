package com.te.threads.runnablewithlamda;

public class RunnableWithLamda {

	public static void main(String[] args) {
		System.out.println("--main start----");

		Runnable ref = () -> {
			System.out.println("---------ThreadOne Start ----");
			String str[] = { "a", "b", "c", "d" };
			for (String string : str) {
				System.out.println(string);
			}
			System.out.println("----------Threadone Ends----");

		};

		Runnable ref2 = () -> {
			System.out.println("--------ThreadTwo Start-----");
			int[] num = { 3, 4, 2, 7, 10 };
			for (int i : num) {
				System.out.println(i);
			}
			System.out.println("----------Threadtwo End----");

		};

		Thread thread1 = new Thread(ref);
		Thread thread2 = new Thread(ref2);
		thread1.start();
		thread2.start();
		System.out.println("-----main ends-------");

	}
}