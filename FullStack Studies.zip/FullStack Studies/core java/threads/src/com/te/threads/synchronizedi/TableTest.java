package com.te.threads.synchronizedi;

public class TableTest {
public static void main(String[] args) {

	Tables ref = new Tables();
	
	Runnable ref1 = ()->{
	    ref.table(3);
		
	};
	
	Runnable ref2 = ()->{
		ref.table(4);
	};
	
	Thread thread = new Thread(ref1);
	Thread thread2 = new Thread(ref2);
	thread.start();
	thread2.start();
}
	
}
