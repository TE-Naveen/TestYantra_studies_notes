package com.te.threads.synchronizedi;

public class TableTest2UsingBlockSynchronized {
public static void main(String[] args) {
	System.out.println("------main thread start----");

	Tables2SynchronizedBlock ref = new Tables2SynchronizedBlock();
	
	Runnable ref1 = ()->{
		System.out.println("first thread Start");
		synchronized(ref){   ///using synchronized block
	    ref.table(3);
		}
		System.out.println("First thread ends");
	};
	
	Runnable ref2 = ()->{
		System.out.println("second thread");
		synchronized(ref) {     ///using synchronized block
		ref.table(4);
		System.out.println("");
		}
		System.out.println("second end");
		
	};
	
	Thread thread = new Thread(ref1);
	Thread thread2 = new Thread(ref2);
	thread.start();
	thread2.start();
    System.out.println("main ends");
}

	
}
