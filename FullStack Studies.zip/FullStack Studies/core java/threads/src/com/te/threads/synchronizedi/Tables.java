package com.te.threads.synchronizedi;

public class Tables {
	//Synchronize keyword must be used to make the thread safe
public synchronized void table(int a) {
	
	for (int i = 1; i < 11; i++) {
		System.out.println(i+a);
	}
	
}
	
}
