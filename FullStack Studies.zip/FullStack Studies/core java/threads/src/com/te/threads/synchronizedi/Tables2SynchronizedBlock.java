package com.te.threads.synchronizedi;

public class Tables2SynchronizedBlock {
	
public  void table(int a) {
	
	for (int i = 1; i < 11; i++) {
		System.out.println(i+a);
	}
	
}
	
}
