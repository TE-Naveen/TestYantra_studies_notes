package com.te.threads.threadsimpl;

public class ThreadOneTest extends Thread{
	@Override
	public void run() {
		String arr[] = {"n","b","c","h"};
		for (String string : arr) {
			System.out.println(string);
		}
	}

}
