package com.te.threads.threadsimpl;

public class ThreadTwo extends Thread{

	 public void run() {
		 for (int i = 12; i >0; i--) {
			System.out.println(i);
		}
	 }
	
}
