package com.te.threads.threadsimpl;

public class ThreadTwoTest {
	public static void main(String[] args) {
		
		System.out.println("--------------mainStarts--------");
		ThreadOne ref = new ThreadOne();
		ThreadTwo ref2 = new ThreadTwo();
		
	/*ref.run(); Note if run method is called only run method function will be 
		            executed.
		ref2.run(); */
		ref.start();
		ref2.start();
		System.out.println("-----main ends------");
		
	}

}
