package com.te.hibernatemapping;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.te.hibernatemapping.beans.PrimaryInfoBean;
import com.te.hibernatemapping.beans.ProjectInfo;

public class Test {
	public static void main(String[] args) {
		
		PrimaryInfoBean bean = new PrimaryInfoBean();
		bean.setEmpId(60);
		bean.setName("kiran");
		bean.setSalary(98799.00);
		
		ProjectInfo projectInfo1 = new ProjectInfo();
		projectInfo1.setPid(10);
		projectInfo1.setProjectName("EMS");
		
		ProjectInfo projectInfo2 = new ProjectInfo();
		projectInfo2.setPid(20);
		projectInfo2.setProjectName("e-Survey");
		
		List<PrimaryInfoBean> primaryInfoBeans = new ArrayList<PrimaryInfoBean>();
		primaryInfoBeans.add(bean);
		
		
		projectInfo1.setEmployees(primaryInfoBeans);
		projectInfo2.setEmployees(primaryInfoBeans);
		
		List<ProjectInfo> projectInfos = new ArrayList<ProjectInfo>();
		projectInfos.add(projectInfo1);
		projectInfos.add(projectInfo2);
		
		bean.setProjects(projectInfos);
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("mapping");
		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		manager.persist(bean);
		manager.getTransaction().commit();
		System.out.println("success");
		manager.close();
		factory.close();
	}
}
