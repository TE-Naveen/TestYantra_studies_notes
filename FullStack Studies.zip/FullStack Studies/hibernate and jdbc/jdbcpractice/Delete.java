package com.te.jdbcpractice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Delete {

	public static void main(String[] args) {
		
		Connection conn = null;
		Statement stmt = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			String dbUrl = "jdbc:mysql://localhost:3306/technoelevate?user=root&password=root";
			conn = DriverManager.getConnection(dbUrl);
			
			String query = "delete from interns where id = 110";
			stmt = conn.createStatement();
			
			int res = stmt.executeUpdate(query);
			
			System.out.println("No of rows Effected :"+res);
			
		} catch (Exception e) {
		e.printStackTrace();
		}
		finally {
			try {
				
				if(conn != null) {
					conn.close();
				}
				if(stmt != null) {
					stmt.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}
