package com.te.jdbcpractice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Insert {

	public static void main(String[] args) {
		
		Connection conn = null;
		Statement stmt = null;
		
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			
			String dbUrl = "jdbc:mysql://localhost:3306/technoelevate?user=root&password=root";
			conn = DriverManager.getConnection(dbUrl);
			
			String query = "insert into interns values('Rakesh',110,'1990-03-28','M','actor',9807689467,45666.00,300,'Rakesh@gmail.com','AB-',300,40)";
			stmt = conn.createStatement();
			
			int result = stmt.executeUpdate(query);
			
			System.out.println("No Of Effected : "+ result);
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(conn != null) {
					conn.close();
				}
				if(stmt != null) {
					stmt.close();
				}
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}
