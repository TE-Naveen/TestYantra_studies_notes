package com.te.jdbcpractice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JDBCIntro {

	public static void main(String[] args) {

		Connection connection = null;
		Statement statement = null;
		ResultSet result = null;

		try {

			// Step1- Load The Driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded");

			// Step2-Get DB connection via Driver
			String dburl = "jdbc:mysql://localhost:3306/technoelevate?user=root&password=root";
			connection = DriverManager.getConnection(dburl);

			// Step3-Issues on sql quaries via connection
			String query = "select * from interns";
			statement = connection.createStatement();

			result = statement.executeQuery(query);

			// Step4-Process the result return from the Sql queries
			int i = 0;
			while (result.next()) {
				System.out.println("-------------" + i + "--------------------");
				System.out.println("Name   : " + result.getString("name"));
				System.out.println("Id     : " + result.getInt("id"));
				System.out.println("DOB    : " + result.getDate("DOB"));
				System.out.println("Gender : " + result.getString("gender"));
				System.out.println("Role   : " + result.getString("Role"));
				System.out.println("Mobile : " + result.getLong("mobile"));
				System.out.println("Salary : " + result.getDouble("salary"));
				System.out.println("DeptId : " + result.getInt("deptid"));
				System.out.println("Email  : " + result.getString("Email"));
				System.out.println("blood G: " + result.getString("Blood_Group"));
				System.out.println("Comm   : " + result.getInt("Comm"));
				System.out.println("MGR    : " + result.getInt("Mgr"));
				System.out.println("-------------" + i + "--------------------");
				i++;
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		//Step5-Close the all the Jdbc objects
		finally {
			try {

				if (connection != null) {
					connection.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (result != null) {
					result.close();
				}

			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}
}
