package com.te.jdbcpractice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class JdbcUpdate {
	
	public static void main(String[] args) {
		 Connection connection = null;
		// Statement stmt = null;
		 PreparedStatement stmt = null;
		 
		 try {
			 
			 //step1-Load the driver
			 Class.forName("com.mysql.jdbc.Driver");
			 
			 //Step2-Get the db Connection via driver
			 String dbUrl = "jdbc:mysql://localhost:3306/technoelevate?user=root&password=root";
			 connection = DriverManager.getConnection(dbUrl);
			 
			 //step3-Issues on Sql queries via connection
			 String query = "update interns set name=? where id=?";
			 //stmt = connection.createStatement();
			 stmt = connection.prepareStatement(query);
			 stmt.setString(1, args[0]);
			 stmt.setInt(2, Integer.parseInt(args[1]));
			 int res = stmt.executeUpdate();
			 
			 if(res==1) {
			 System.out.println("Updated Successfully");
			 }
		} catch (Exception e) {
			e.printStackTrace();
		}
		 finally {
			 try {
				 if(connection != null) {
					 connection.close();
				 }
				 if(stmt != null) {
					 stmt.close();
				 }
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		 }
	}

}
