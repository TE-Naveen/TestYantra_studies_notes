package com.te.jdbcpractice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Jdbd5Steps {
	
	public static void main(String[] args) {
		 
		Connection connection = null;
		
		Statement stmt = null;
		
		ResultSet result = null;
		
		try {
			//step1-Load The Driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//Step2-Get the Connection via Driver
			String dburl = "jdbc:mysql://localhost:3306/technoelevate?user=root&password=root";
			connection = DriverManager.getConnection(dburl);
			
			//step3-Issues on sql queries via connection
			String query = "select * from interns where id=10";
			stmt = connection.createStatement();
			
			result = stmt.executeQuery(query);
			
			//step4-process the result return from the sql queries
			if(result.next()) {
				System.out.println(result.getString("name"));
				System.out.println(result.getInt("id"));
				System.out.println(result.getDate("dob"));
				System.out.println(result.getString("gender"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//step5 - Close the All the jdbc objects
		finally {
			try {
				if(connection != null) {
					connection.close();
				}
				if(stmt != null) {
					stmt.close();
				}
				if(result != null) {
					result.close();
				}
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		
	}

}
