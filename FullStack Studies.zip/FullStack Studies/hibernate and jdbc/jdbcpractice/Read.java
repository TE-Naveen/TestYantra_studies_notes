package com.te.jdbcpractice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Read {
	
	public static void main(String[] args) {
		
		Connection connection = null;
		Statement stmt = null;
		ResultSet result = null;
		
		try {
			//Step1-Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//Step2-Get db connection via Driver
			String dbUrl = "jdbc:mysql://localhost:3306/technoelevate?user=root&password=root";
			connection = DriverManager.getConnection(dbUrl);
			
			//Step3-Issues on sql quaries via connection
			String query = "select * from interns";
			
			stmt = connection.createStatement();
			
			result = stmt.executeQuery(query);
			
			//Step4-Process the result return from sql queries
			int i=0;
			while(result.next()) {
				System.out.println("-------------"+ i +"--------------");
				System.out.println("Name : "+result.getString("name"));
				System.out.println("Id : "+result.getInt("id"));
				System.out.println("Date of birth : "+result.getDate("dob"));
				System.out.println("Gender : "+result.getString("gender"));
				System.out.println(" Role : "+result.getString("role"));
				System.out.println("Mobile No : "+result.getLong("mobile"));
				System.out.println("Salary : "+result.getDouble("salary"));
				System.out.println("DeptId : "+result.getInt("deptid"));
				System.out.println("EmailId : "+result.getString("email"));
				System.out.println("BloodGroup : "+result.getString("blood_group"));
				System.out.println("Commision : "+result.getInt("comm"));
				System.out.println("ReportingManager : "+result.getInt("mgr"));
				
				i++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				
				if(connection != null) {
					connection.close();
				}
				if(stmt != null) {
					stmt.close();
				}
				if(result != null) {
					result.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
		

}
