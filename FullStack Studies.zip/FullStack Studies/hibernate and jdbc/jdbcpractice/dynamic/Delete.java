package com.te.jdbcpractice.dynamic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Delete {

	public static void main(String[] args) {
		
		Connection conn = null;
		PreparedStatement stmt = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			String dbUrl = "jdbc:mysql://localhost:3306/technoelevate?user=root&password=root";
			conn = DriverManager.getConnection(dbUrl);
			
			String query = "delete from interns where id = ?";
			stmt = conn.prepareStatement(query);
			
			stmt.setInt(1, Integer.parseInt(args[0]));
			
			int res = stmt.executeUpdate();
			
			if(res == 1) {
				System.out.println("Deleted successfully");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(conn != null) {
					
					conn.close();
				}
				if(stmt != null) {
					stmt.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}
