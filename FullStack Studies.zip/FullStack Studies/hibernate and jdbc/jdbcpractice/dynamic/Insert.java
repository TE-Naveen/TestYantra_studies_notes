package com.te.jdbcpractice.dynamic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Insert {
	
	public static void main(String[] args) {
		
		Connection conn = null;
		PreparedStatement stmt = null;
		
		try {
			 
			Class.forName("com.mysql.jdbc.Driver");
			
			String dbUrl = "jdbc:mysql://localhost:3306/technoelevate?user=root&password=root";
			conn = DriverManager.getConnection(dbUrl);
			
			String query = " insert into interns values(?,?,?,?,?,?,?,?,?,?,?,?)";
			stmt = conn.prepareStatement(query);
			
			stmt.setString(1,args[0]);
			stmt.setInt(2,Integer.parseInt(args[1]));
			stmt.setDate(3, java.sql.Date.valueOf(args[2]));
			stmt.setString(4,args[3]);
			stmt.setString(5,args[4]);
			stmt.setLong(6,Long.parseLong(args[5]));
			stmt.setDouble(7,Double.parseDouble(args[6]));
			stmt.setInt(8,Integer.parseInt(args[7]));
			stmt.setString(9,args[8]);
			stmt.setString(10,args[9]);
			stmt.setInt(11,Integer.parseInt(args[10]));
			stmt.setInt(12, Integer.parseInt(args[11]));
			
			
			
			int res = stmt.executeUpdate();
			
			
			System.out.println("No of rows Effected : "+res);
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
