package com.te.jdbcpractice.dynamic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Read {
	public static void main(String[] args) {

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet res = null;
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			
			String dbUrl = "jdbc:mysql://localhost:3306/technoelevate?user=root&password=root";
			conn = DriverManager.getConnection(dbUrl);
			
			String query = "select * from interns where id=?";
			
			stmt = conn.prepareStatement(query);
			stmt.setInt(1, Integer.parseInt(args[0]));
			res = stmt.executeQuery();
			
			if(res.next()) {
				System.out.println("Name : "+res.getString("name"));
				System.out.println("Id : "+res.getInt("id"));
				System.out.println("Date of Birth : "+res.getDate("dob"));
				System.out.println("Gender : "+res.getString("gender"));
				System.out.println("Role : "+res.getString("role"));
				System.out.println("mobile : "+res.getLong("mobile"));
				System.out.println("salary : "+res.getDouble("salary"));
				System.out.println("deptId : "+res.getInt("deptid"));
				System.out.println("email : "+res.getString("email"));
				System.out.println("Blood_group : "+res.getString("blood_group"));
				System.out.println("Commission : "+res.getInt("comm"));
				System.out.println("Reporting Maneger : "+res.getInt("mgr"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(conn != null) {
					conn.close();
				}
				if(stmt != null) {
					stmt.close();
				}
				if(res != null) {
					res.close();
				}
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}
}
