package com.te.jdbcpractice.propertiesfile;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

public class DynamicReadQuery {

	public static void main(String[] args) {

		FileInputStream input = null;
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			
			input = new FileInputStream("dbInfo.properties");
			Properties prop = new Properties();
			prop.load(input);
			
			//step1
			Class.forName(prop.getProperty("driver"));
			
			//step2
			conn = DriverManager.getConnection(prop.getProperty("dbUrl"),prop);
			
			//step3
			String query ="select * from interns where id=?";
			preparedStatement =conn.prepareStatement((query));
			
			preparedStatement.setInt(1, Integer.parseInt(args[0]));
			
			resultSet = preparedStatement.executeQuery();
			
			
			//step4
			
			if(resultSet.next()) {
				System.out.println("Name   : " + resultSet.getString("name"));
				System.out.println("Id     : " + resultSet.getInt("id"));
				System.out.println("DOB    : " + resultSet.getDate("DOB"));
				System.out.println("Gender : " + resultSet.getString("gender"));
				System.out.println("Role   : " + resultSet.getString("Role"));
				System.out.println("Mobile : " + resultSet.getLong("DOB"));
				System.out.println("Salary : " + resultSet.getDouble("salary"));
				System.out.println("DeptId : " + resultSet.getInt("deptid"));
				System.out.println("blood G: " + resultSet.getString("Blood_Group"));
				System.out.println("Email  : " + resultSet.getString("Email"));
				System.out.println("Comm   : " + resultSet.getInt("Comm"));
				System.out.println("MGR    : " + resultSet.getInt("Mgr"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(conn != null) {
					conn.close();
				}
				if(preparedStatement != null) {
					preparedStatement.close();
				}
				if(resultSet != null) {
					resultSet.close();
				}
				if(input != null) {
					input.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}
