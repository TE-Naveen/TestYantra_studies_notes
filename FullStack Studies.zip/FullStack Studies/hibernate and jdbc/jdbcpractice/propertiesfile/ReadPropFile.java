package com.te.jdbcpractice.propertiesfile;

import java.io.FileInputStream;
import java.util.Properties;

public class ReadPropFile {
	
	public static void main(String[] args) throws Exception {
		FileInputStream inputStream = new FileInputStream("C:\\Users\\deepu reddy.L\\OneDrive\\Desktop\\Rasheedty\\properties.txt");
		
		Properties prop = new Properties();
		
		prop.load(inputStream);
		System.out.println(prop.get("user"));
		System.out.println(prop.get("password"));
		System.out.println(prop.get("dbUrl"));
		System.out.println(prop.get("driver"));

	}

}
