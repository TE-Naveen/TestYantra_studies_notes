package com.te.jdbcpractice.propertiesfile;

import java.io.FileOutputStream;
import java.util.Properties;

public class WritePropFile {

public static void main(String[] args) throws Exception {
		
		FileOutputStream outputStream = new FileOutputStream("C:\\Users\\deepu reddy.L\\OneDrive\\Desktop\\Rasheedty\\properties.txt");
		Properties prop = new Properties();
		
		prop.setProperty("user", "root");
		prop.setProperty("password", "root");
		prop.setProperty("dbUrl", "jdbc:mysql://localhost:3306/technoelevate");
		prop.setProperty("driver", "com.mysql.jdbc.Driver");
		prop.store(outputStream,"DB Information");
		System.out.println("  success ");
	}
}
