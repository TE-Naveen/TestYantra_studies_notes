package com.te.jpawithhibernate.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "movies_info")
@Data
public class MovieInfo {
	@Column
	@Id
	private Integer movieId;
	@Column
	private String name;

}
