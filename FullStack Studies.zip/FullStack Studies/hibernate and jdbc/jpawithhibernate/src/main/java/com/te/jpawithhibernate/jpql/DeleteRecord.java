package com.te.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.transaction.Transaction;
import javax.transaction.Transactional;

public class DeleteRecord {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("interns");
		EntityManager manager = factory.createEntityManager();

		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		String delete = "delete InternsInfo where id = 70";

		Query query = manager.createQuery(delete);

		int res = query.executeUpdate();

		System.out.println(res + " no of rows effected");

		transaction.commit();
		manager.close();
		factory.close();
	}

}
