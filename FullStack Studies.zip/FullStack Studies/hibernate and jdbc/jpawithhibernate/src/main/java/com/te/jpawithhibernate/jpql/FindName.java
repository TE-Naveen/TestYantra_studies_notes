package com.te.jpawithhibernate.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class FindName {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("interns");
		EntityManager manager = factory.createEntityManager();

		String findName = "select name from InternsInfo";

		Query query = manager.createQuery(findName);

		List<String> list = query.getResultList();

		for (String name : list) {
			System.out.println(name);
			System.out.println("--------------------");

		}
		
		String multi = "select name,id from InternsInfo";
		Query query2 = manager.createQuery(multi);
		
		List<Object[]> list2 = query2.getResultList();
		
		for (Object[] ob : list2) {
			System.out.println(ob[0]);
			System.out.println(ob[1]);
			System.out.println("---------------------");
			
		}
	}

}
