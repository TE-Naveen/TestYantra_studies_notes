package com.te.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class UpdateRecord {

	public static void main(String[] args) {
		try {

			EntityManagerFactory factory = Persistence.createEntityManagerFactory("interns");
			EntityManager manager = factory.createEntityManager();

			EntityTransaction transaction = manager.getTransaction();

			transaction.begin();

			String update = "update InternsInfo set name = 'Boopathivsr'," + "salary=70000.00 where id = 70";

			Query query = manager.createQuery(update);

			int res = query.executeUpdate();

			System.out.println(res + "no of rows effected");

			transaction.commit();
			manager.close();
			factory.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
