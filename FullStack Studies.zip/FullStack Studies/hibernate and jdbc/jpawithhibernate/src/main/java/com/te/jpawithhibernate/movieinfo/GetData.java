package com.te.jpawithhibernate.movieinfo;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.te.jpawithhibernate.beans.MovieInfo;

public class GetData {
	static Logger LOGGER = Logger.getLogger("org.hibernate");

	public static void main(String[] args) {

		LOGGER.setLevel(Level.SEVERE);
		try {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("movies_info");

			EntityManager em = emf.createEntityManager();

			MovieInfo movieInfo = em.getReference(MovieInfo.class, 1);

			if (movieInfo != null) {

				System.out.println(movieInfo.getName());
				em.close();
				emf.close();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
