package com.te.jpawithhibernate.movieinfo;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.Transaction;

import com.te.jpawithhibernate.beans.MovieInfo;

public class InsertData {
	static Logger LOGGER = Logger.getLogger("org.hibernate");

	public static void main(String[] args) {

		LOGGER.setLevel(Level.SEVERE);
		EntityTransaction transaction = null;

		MovieInfo movieInfo = new MovieInfo();
		movieInfo.setMovieId(1);
		movieInfo.setName("Avengers");
		try {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("movies_info");
			EntityManager em = emf.createEntityManager();
			transaction = em.getTransaction();
			transaction.begin();
			em.persist(movieInfo);
			transaction.commit();
			System.out.println("inserted");
			emf.close();
			em.close();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}

	}
}
