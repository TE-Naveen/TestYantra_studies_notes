package com.te.designpattern.creational;

public interface Employee {

	void employeeDetail();

}
