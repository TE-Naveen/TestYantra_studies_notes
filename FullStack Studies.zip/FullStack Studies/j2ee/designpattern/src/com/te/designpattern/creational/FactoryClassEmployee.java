package com.te.designpattern.creational;

public class FactoryClassEmployee {

	static Employee Empdetail(String Emp) {

		if (Emp.equalsIgnoreCase("manager")) {
			return new Manager();
		} else if (Emp.equalsIgnoreCase("intern")) {
			return new Intern();
		}
		return null;

	}

}
