package com.te.designpattern.creational;

public class Intern  implements Employee{

	@Override
	public void employeeDetail() {
		// TODO Auto-generated method stub
		System.out.println("Intern employee");
	}
	
	

}
