package com.te.designpattern.creational;

public class Manager  implements Employee{

	public void employeeDetail() {
		// TODO Auto-generated method stub
		System.out.println(" manager employee");
	}

	
}
