package designpatternbehaviour.strategy;

public class ContextStrategy  implements Strategy{

	@Override
	public int doOperation(int a, int b) {
		// TODO Auto-generated method stub
		return 0v a;
	}

	
	
	
}
