package designpatternbehaviour.strategy;

public class Login implements Strategy {

	@Override
	public int doOperation(int a, int b) {
		// TODO Auto-generated method stub
		return 1;
	}

}
