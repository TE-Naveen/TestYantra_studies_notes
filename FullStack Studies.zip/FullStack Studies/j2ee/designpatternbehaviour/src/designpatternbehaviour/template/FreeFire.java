package designpatternbehaviour.template;

public class FreeFire implements Game {

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("------FREE fire IS loading------");
		
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("choose the map");
		
	}

	@Override
	public void end() {
		// TODO Auto-generated method stub
		System.out.println("----you lost  **5 position better luck next time-----");
		
	}

	
}
