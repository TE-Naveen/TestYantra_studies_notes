package designpatternbehaviour.template;

public class PUBG implements Game {

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("----PUBG IS STARTED------");
		
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("map is loading");
		
	}

	@Override
	public void end() {
		// TODO Auto-generated method stub
		System.out.println("-----you lost 3**positon better luck next time-----");
		
	}

	
}
