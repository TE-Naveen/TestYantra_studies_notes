package designpatternbehaviour.template;

public class TestGame {
	public static void main(String[] args) {

		System.out.println("---Welcome to  game--------");
		Game game = new PUBG();
		game.play();


		Game game2 = new FreeFire();
		game2.play();

	}

}
