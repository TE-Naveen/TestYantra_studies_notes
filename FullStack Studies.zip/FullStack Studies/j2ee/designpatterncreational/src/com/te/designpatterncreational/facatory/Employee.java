package com.te.designpatterncreational.facatory;

public interface Employee {

	void employeeDetail();

}
