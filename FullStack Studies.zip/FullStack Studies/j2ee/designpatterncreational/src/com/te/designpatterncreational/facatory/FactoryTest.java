package com.te.designpatterncreational.facatory;

import java.util.Scanner;

public class FactoryTest {
	static final Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		while (true) {
			System.out.println("enter the detail");
			String str = scanner.nextLine();
			Employee emp = FactoryClassEmployee.Empdetail(str);
			try {
				emp.employeeDetail();
			} catch (Exception e) {

				System.out.println("nullpointerException handled");
				
			}

		}
	}
}
