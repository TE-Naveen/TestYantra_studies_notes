package com.te.designpatterncreational.facatory;

public class Intern  implements Employee{

	@Override
	public void employeeDetail() {
		// TODO Auto-generated method stub
		System.out.println("Intern employee");
	}
	
	

}
