package com.te.designpatterncreational.facatory;

public class Manager  implements Employee{

	public void employeeDetail() {
		// TODO Auto-generated method stub
		System.out.println(" manager employee");
	}

	
}
