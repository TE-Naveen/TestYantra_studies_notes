package com.te.designpatterncreational.prototype;

public class ProtoTypeExample {

	private ProtoTypeExample() {
		// TODO Auto-generated constructor stub
	}

	static ProtoTypeExample getInstance() {
		return new ProtoTypeExample();

	}
}
