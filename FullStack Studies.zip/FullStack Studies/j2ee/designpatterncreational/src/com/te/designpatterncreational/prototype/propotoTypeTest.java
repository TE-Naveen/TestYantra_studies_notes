package com.te.designpatterncreational.prototype;

public class propotoTypeTest {
	public static void main(String[] args) {
		System.out.println(ProtoTypeExample.getInstance().hashCode());
		System.out.println(ProtoTypeExample.getInstance().hashCode());
	}

}
