package com.te.designpatterncreational.singleton;

public class SingleTonExample {

	public static SingleTonExample object = null;

	private SingleTonExample() {

	}

	static SingleTonExample getInstance() {
		if (object == null) {
			object = new SingleTonExample();
		}
		return object;
	}

	void add(int a, int b) {
		System.out.println(a + b);
	}

	void subtract(int a, int b) {
		System.out.println(a - b);
	}
}