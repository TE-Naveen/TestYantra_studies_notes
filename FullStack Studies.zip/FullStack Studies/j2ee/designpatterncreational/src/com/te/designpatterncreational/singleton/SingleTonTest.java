package com.te.designpatterncreational.singleton;

public class SingleTonTest {
	public static void main(String[] args) {
		SingleTonExample ref = SingleTonExample.getInstance();
		System.out.println(ref.hashCode());
		ref.add(10, 29);
		SingleTonExample ref2 = SingleTonExample.getInstance();
		System.out.println(ref2.hashCode());
		ref2.subtract(2, 10);
	}

}
