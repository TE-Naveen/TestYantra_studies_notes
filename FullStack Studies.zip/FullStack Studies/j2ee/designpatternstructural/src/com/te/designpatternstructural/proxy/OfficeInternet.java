package com.te.designpatternstructural.proxy;

public interface OfficeInternet {
public void getInternetAccess();
}
