package com.te.designpatternstructural.proxy;

public class ProxyDptest {
public static void main(String[] args) {
	OfficeInternet internet = new ProxyInternetAccess("Abc");
	internet.getInternetAccess();
}
	
}
