package com.te.designpatternstructural.proxy;

import java.security.PublicKey;

public class ProxyInternetAccess implements OfficeInternet {

	private String employeeName;
	
	private RealInternetAccess internetaccess;
	 public ProxyInternetAccess(String employeeName) {
		// TODO Auto-generated constructor stub
	}
	@Override
	public void getInternetAccess() {
		// TODO Auto-generated method stub
		if(getLevel() > 5) {
			internetaccess = new RealInternetAccess(employeeName);
			internetaccess.getInternetAccess();
		}else {
			System.out.println("Level is below 5!!");
		}
	}
		public long getLevel() {
			return Math.round(Math.random()*10);
		}
		
	} 
	 
	 
		
	
	
	
}
