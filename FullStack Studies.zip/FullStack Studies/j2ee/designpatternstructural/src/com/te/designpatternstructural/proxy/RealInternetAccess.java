package com.te.designpatternstructural.proxy;

public class RealInternetAccess implements OfficeInternet {

	
	private String employeename;
	
	public RealInternetAccess (String name) {
		
		this.employeename= name;
	}
	@Override
	public void getInternetAccess() {
		
		
	}
	
}
