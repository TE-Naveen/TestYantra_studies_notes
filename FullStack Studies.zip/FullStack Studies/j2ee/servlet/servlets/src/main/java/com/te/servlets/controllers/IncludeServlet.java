package com.te.servlets.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/include")
public class IncludeServlet  extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
//		String url = "./MyForm.html"; //static resource
		String url = "./second"; //dynamic resource
		
		PrintWriter out = resp.getWriter();
		
		out.println("<h1> This  page is going to include  Second</h1>");
		
		req.getRequestDispatcher(url).include(req, resp);
		
	}
}












