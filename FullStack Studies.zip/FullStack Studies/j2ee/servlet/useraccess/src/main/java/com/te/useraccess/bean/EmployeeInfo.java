package com.te.useraccess.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table (name="webconsole")
public class EmployeeInfo implements Serializable{

	@Column
	@Id
	private Integer id;
	
	@Column
	private String name;
	
	@Column
	private String gender;
	
	@Column
	private String role;

	@Column
	private String email;
	
	@Column
	private Integer phone;
	
	@Column
	private String password;
}

