package com.te.useraccess.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.te.useraccess.dao.Login;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String result = Login.login(Integer.parseInt(req.getParameter("id")), req.getParameter("password"));

		if (result.equalsIgnoreCase("login success")) {
			resp.sendRedirect("./loginsuccess.html");

		} else if (result.equalsIgnoreCase("login failed enter the valid credentials")) {
			resp.sendRedirect("loginfailed.html");
			
		}

	}
}
