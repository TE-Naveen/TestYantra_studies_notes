package com.te.useraccess.controllers;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.te.useraccess.bean.EmployeeInfo;
import com.te.useraccess.dao.ShowDetails;

@WebServlet("/ViewData")
public class ShowDetailsServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		resp.setContentType("text/html");
		EmployeeInfo obj = ShowDetails.showDetails();

		PrintWriter out = resp.getWriter();
		out.println("<body>");
		out.println("<h2> YOUR DETAILS </h2>");

		out.print(" <h2>Name : </h2>" + " " + obj.getName());
		out.print(" <h2>Email :</h2>" + " " + obj.getEmail());
		out.print(" <h2>Gender :</h2>" + " " + obj.getGender());
		out.print(" <h2>password :</h2>" + " " + obj.getPassword());
		out.print(" <h2>Role :</h2>" + " " + obj.getRole());
		out.print(" <h2>ID :</h2>" + " " + obj.getId());
       out.println("</body>");
	}

	/*
	 * private static EmployeeInfo showDetails() { // TODO Auto-generated method
	 * stub return null; }
	 */

}
