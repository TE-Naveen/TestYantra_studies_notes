package com.te.useraccess.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.te.useraccess.bean.EmployeeInfo;
import com.te.useraccess.dao.Login;
//import com.te.weproject.bean.EmployeeInfo;
import com.te.useraccess.dao.UpdateDetails;

@WebServlet("/updatedetails")
public class UpdateServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		Integer ival = Integer.parseInt(req.getParameter("id"));
		int id = ival.intValue();
		if (id == Login.loginId) {

			EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
			EntityManager entitymanager = factory.createEntityManager();
			EmployeeInfo info = entitymanager.getReference(EmployeeInfo.class, Login.loginId);
			EntityTransaction transaction = entitymanager.getTransaction();

			transaction.begin();
			info.setName(req.getParameter("name"));
			info.setGender(req.getParameter("gender"));
			info.setRole(req.getParameter("role"));
			info.setEmail(req.getParameter("email"));
			info.setPhone((Integer.parseInt(req.getParameter("phone"))));
			info.setPassword(req.getParameter("password"));
			entitymanager.persist(info);
			transaction.commit();
			out.println("<h2>update success</h2>");

		} else {
			out.println("<h2>update failed</h2>");
		}
	}
}
