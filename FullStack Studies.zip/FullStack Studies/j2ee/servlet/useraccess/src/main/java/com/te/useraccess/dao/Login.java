package com.te.useraccess.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.te.useraccess.bean.EmployeeInfo;
                       
public class Login {
 public static int loginId;
	public static String login(int id, String password) {
         loginId=id;
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
		EntityManager manager = factory.createEntityManager();

		try {
			EmployeeInfo info = manager.getReference(EmployeeInfo.class, id);
			if (info != null) {
				int ival = info.getId();
				String str = info.getPassword();
				if (ival == id & password.equals(str)) {
					return "login success";

				} else {
					return "login failed enter the valid credentials";
				}

			}
		} catch (Exception e) {
			return "login failed enter the valid credentials";
		}
		return "";
	}
	
	}



