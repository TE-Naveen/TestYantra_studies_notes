package com.te.useraccess.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.te.useraccess.bean.EmployeeInfo;

public class ShowDetails {
	public static EmployeeInfo showDetails() {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
		EntityManager manager = factory.createEntityManager();
		EmployeeInfo info = manager.getReference(EmployeeInfo.class, Login.loginId);
		return info;


	}

}

