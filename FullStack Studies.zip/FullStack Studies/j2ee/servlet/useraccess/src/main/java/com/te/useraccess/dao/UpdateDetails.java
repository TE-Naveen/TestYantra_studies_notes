package com.te.useraccess.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.http.HttpServletRequest;

import com.te.useraccess.bean.EmployeeInfo;

public class UpdateDetails {
	public static String update(HttpServletRequest req) {
		Integer ival = Integer.parseInt(req.getParameter("id"));
		int id = ival.intValue();
		if (id == Login.loginId) {
			EntityManagerFactory factory = Persistence.createEntityManagerFactory("employee");
			EntityManager entitymanager = factory.createEntityManager();
			EmployeeInfo info = entitymanager.getReference(EmployeeInfo.class, Login.loginId);
			EntityTransaction transaction = entitymanager.getTransaction();

			transaction.begin();
			info.setName(req.getParameter("name"));
			info.setGender(req.getParameter("gender"));
			info.setRole(req.getParameter("role"));
			info.setEmail(req.getParameter("email"));
			info.setPhone((Integer.parseInt(req.getParameter("phone"))));
			info.setPassword(req.getParameter("password"));
			entitymanager.persist(info);
			transaction.commit();

			return "success";
		} else {
			return "mismatch";
		}

	}
}
