package com.te.resume5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Resume5Application {

	public static void main(String[] args) {
		SpringApplication.run(Resume5Application.class, args);
	}

}
