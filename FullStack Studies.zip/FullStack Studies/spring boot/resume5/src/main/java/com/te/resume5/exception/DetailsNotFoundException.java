package com.te.resume5.exception;

public class DetailsNotFoundException extends RuntimeException{

	public DetailsNotFoundException(String msg) {
		super(msg);
	}
}
