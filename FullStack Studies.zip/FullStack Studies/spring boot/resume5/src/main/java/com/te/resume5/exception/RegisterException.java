package com.te.resume5.exception;

public class RegisterException extends RuntimeException{

	public RegisterException(String msg) {
		super(msg);
	}
}
