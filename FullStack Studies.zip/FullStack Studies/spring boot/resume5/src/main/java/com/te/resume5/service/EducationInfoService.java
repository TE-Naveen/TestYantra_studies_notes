package com.te.resume5.service;

import java.util.List;

import com.te.resume5.beans.EducationInfo;

public interface EducationInfoService {

	public List<EducationInfo> registerEducationInfo(List<EducationInfo> educationInfo);
}
