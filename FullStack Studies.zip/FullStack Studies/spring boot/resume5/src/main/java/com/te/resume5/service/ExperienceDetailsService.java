package com.te.resume5.service;

import java.util.List;

import com.te.resume5.beans.ExperienceDetails;

public interface ExperienceDetailsService {

	public List<ExperienceDetails> registerExperienceDetails(List<ExperienceDetails> experienceDetails);
}
