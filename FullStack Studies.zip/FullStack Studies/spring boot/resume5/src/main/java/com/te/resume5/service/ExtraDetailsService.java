package com.te.resume5.service;

import java.util.List;

import com.te.resume5.beans.ExtraDetails;

public interface ExtraDetailsService {

	public List<ExtraDetails> registerExtraDetails(List<ExtraDetails> extraDetails);
}
