package com.te.resume5.service;

import com.te.resume5.beans.PersonalDetails;

public interface PersonalDetailsService {

	public PersonalDetails registerPersonalDetails(PersonalDetails personalDetails);

	
}
