package com.te.resume5.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.resume5.beans.PersonalDetails;
import com.te.resume5.dao.PersonalDetailsDao;
import com.te.resume5.exception.DetailsNotFoundException;

@Service
public class PersonalDetailsServiceImpl implements PersonalDetailsService{

	@Autowired
	private PersonalDetailsDao dao;
	
	@Override
	public PersonalDetails registerPersonalDetails(PersonalDetails personalDetails) {
		return dao.save(personalDetails);
	}

	

}
