package com.te.springbootchennai.customeexp;

public class EmployeeException extends RuntimeException {

	public EmployeeException(String message) {
		super(message);
	}

}
