package com.te.springbootchennai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootdatajpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
