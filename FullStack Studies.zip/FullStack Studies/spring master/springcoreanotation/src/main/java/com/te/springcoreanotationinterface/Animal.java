package com.te.springcoreanotationinterface;

public interface Animal {
	
	public void eat();
	
	public void sound();
	
	public void type();

}
