package com.te.springcorexmlfinall;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.te.springcorexmlfinall.bean.Employee;

public class EmployeeTest {
	public static void main(String[] args) {
	ApplicationContext context	= new ClassPathXmlApplicationContext("employee2.xml");
	
	Employee emp =context.getBean("emp", Employee.class);
	
	System.out.println("----------Employee details-----------");
	System.out.println(emp.getEmpId());
	System.out.println(emp.getName());
	
	System.out.println("-----department--------");
	System.out.println(emp.getDept().getDeptname());
	System.out.println(emp.getDept().getDeptLocation());
	
	}

}
