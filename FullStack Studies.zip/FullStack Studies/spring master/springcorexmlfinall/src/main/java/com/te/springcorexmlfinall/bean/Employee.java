package com.te.springcorexmlfinall.bean;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Employee  implements Serializable{

	private Integer empId;
	
	private String name;
	
	private department dept;
}
