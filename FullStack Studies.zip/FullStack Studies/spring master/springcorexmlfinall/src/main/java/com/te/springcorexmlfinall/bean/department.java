package com.te.springcorexmlfinall.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class department {
	
	private String deptname;
	
	private String deptLocation;

}
