package com.te.springjaxb.beans;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonRootName;

import lombok.Data;


@XmlRootElement(name="employee-info")//to specifiy the root tag
@XmlAccessorType(XmlAccessType.FIELD)//all fields are non static and private
@JsonRootName("user_info")  //json anotations&&xml
@Data
@JsonPropertyOrder("emp_Id,emp_name")//for the order of priorityid and name will be first
public class EmployeeInfo implements Serializable {

	
	@JsonProperty("emp_Id")
	@XmlElement(name="emp-id")
	private Integer id;

	@JsonProperty("emp_name")
	@XmlElement(name="emp-name")
	private String name;

	@XmlElement(name = "Email-id")
	private String mail;

	
	
	@JsonIgnore
	@XmlTransient
	private String password;

	@XmlElement
	private Date dateOfBirth;

	@XmlElement
	private Date dateOfJoining;

	@XmlElement
	private long mobile;

	@XmlElement
	private String location;

	@XmlElement
	private String desgination;

	@XmlElement
	private boolean isMarried;

	@XmlElement
	private Double salary;
	
	@JsonProperty
	@XmlElement
	private UserOtherInfo otherinfo;
	
	@JsonProperty
	@XmlElementWrapper(name = "user-addresses")//to make the list under a single root element 
	private List<UserAddressBean> addresssBeans;
	
	

}
