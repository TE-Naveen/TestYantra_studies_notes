package com.te.springjaxb.josonmarshlingtest;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.te.springjaxb.beans.EmployeeInfo;

public class JsonMarshlingTest {

public static void main(String[] args) {
	

	EmployeeInfo bean = new EmployeeInfo();
	bean.setDateOfBirth(new Date());
	bean.setDateOfJoining(new Date());
	bean.setId(1);
	bean.setLocation("chennai");
	bean.setMail("david@gmail.com");
	bean.setMarried(true);
	bean.setMobile(123445456l);
	bean.setName("david");
	bean.setPassword("david");
	bean.setSalary(1000.00);
	bean.setDesgination("developer");
	
	ObjectMapper mapper= new  ObjectMapper();
	
	try {
		mapper.writeValue(System.out,bean);
         mapper.writeValue(new File("user.json"), bean);		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
}
}